package com.nttdata.files;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterDemo {
	public static void main(String[] args) {
		try {
			FileWriter fw = new FileWriter("Second.txt");
			fw.write("My file nnnnn");
			fw.close();
		}
		catch(IOException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		System.out.println("rest of the code");
	}
}
