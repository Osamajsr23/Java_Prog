package com.nttdata.files;

public class VoterAssertion {
	String vname;
	int vage;
	VoterAssertion(String vname, int vage)
	{
	this.vname=vname;
	this.vage=vage;
	}
	static int vote;
	public void doVote()
	{
	try {
		//assert varname cond value: not satisfied operation

		assert vage>=18:"Not Eligible to Vote";
		vote++;// satisfied operation

	}
	catch(AssertionError e)
	{
		System.out.println(e);
	}
	}
	static public void printVote()
	{
	System.out.println("Total Number of Voter: "+vote);
	}

}
