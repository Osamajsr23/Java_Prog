package com.nttdata.files;

public class MainAssertion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VoterAssertion v1=new VoterAssertion("John",20);
		v1.doVote();
		VoterAssertion v2=new VoterAssertion("JeJo",17);
		v2.doVote();
		VoterAssertion v3=new VoterAssertion("Joe",23);
		v3.doVote();
		VoterAssertion.printVote();

	}

}
