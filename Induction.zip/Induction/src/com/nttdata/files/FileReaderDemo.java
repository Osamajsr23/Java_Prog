package com.nttdata.files;

import java.io.FileReader;

public class FileReaderDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try 
		{
			FileReader fr = new FileReader("Second.txt");
			int i;
			while((i=fr.read())!=-1)
			{
				System.out.print((char)i);
			}
		} 
		catch (Exception e) 
		{
			System.out.println(e);
			e.printStackTrace();
		}

	}

}
