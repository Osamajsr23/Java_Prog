package com.nttdata.interfacedemo;

public interface Demo {
	int num =10; // public static final int num=10;
	void disp();// public abstract void disp();

}
