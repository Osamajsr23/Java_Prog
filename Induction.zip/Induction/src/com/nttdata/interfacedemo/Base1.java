package com.nttdata.interfacedemo;

public class Base1 {

}
