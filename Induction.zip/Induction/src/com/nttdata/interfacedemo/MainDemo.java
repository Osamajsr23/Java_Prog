package com.nttdata.interfacedemo;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SubDemo d = new SubDemo();
		d.disp();
		d.myDisp();
		System.out.println(Demo.num);
		
	}

}
