package com.nttdata.interfacedemo;

public class SubDemo implements Demo {

	@Override
	public void disp() {
		// TODO Auto-generated method stub
		System.out.println("Interface disp method");
	}
	void myDisp()
	{
		System.out.println("normal method in sub class");
	}
	
	
}
