package com.nttdata.constructor;

public class EmployeeMain {

	public static void main(String[] args) {
		Employee e = new Employee();
		e.dispData();

	}

}
