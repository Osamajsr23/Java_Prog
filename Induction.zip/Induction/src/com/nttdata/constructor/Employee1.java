package com.nttdata.constructor;

public class Employee1 {
	
	int eid;
	String name;
	float exp;
	String address;
	
	Employee1(int id, String name, String add, float exp)
	{
		eid=id;
		this.name=name;
		this.exp=exp;
		address=add;
	}
	void dispData()
	{
		System.out.println("Name:"+name);
		System.out.println("Id:"+eid);
		System.out.println("Location:"+address);
		System.out.println("Experience:"+exp);
	}
}
