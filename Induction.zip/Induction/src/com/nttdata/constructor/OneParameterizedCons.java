package com.nttdata.constructor;

public class OneParameterizedCons {
	
	OneParameterizedCons(int a)
	{
		System.out.println(a);
	}
	OneParameterizedCons(float a)
	{
		System.out.println(a);
	}
	OneParameterizedCons(double a)
	{
		System.out.println(a);
	}
	OneParameterizedCons(char a)
	{
		System.out.println(a);
	}
	OneParameterizedCons(String a)
	{
		System.out.println(a);
	}
}
