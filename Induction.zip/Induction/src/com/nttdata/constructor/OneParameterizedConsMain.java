package com.nttdata.constructor;

public class OneParameterizedConsMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OneParameterizedCons c1 = new OneParameterizedCons(2);
		OneParameterizedCons c2 = new OneParameterizedCons(2.4f);
		OneParameterizedCons c3 = new OneParameterizedCons(22.3);
		OneParameterizedCons c4 = new OneParameterizedCons("s");
		OneParameterizedCons c5 = new OneParameterizedCons("renu");
	}

}
