package com.nttdata.constructor;

public class Employee {
	int eid;
	String name;
	float exp;
	String address;
	
	Employee()
	{
		eid=102;
		exp=1.2f;
		name="Harry";
		address="Bangalore";
	}
	void dispData()
	{
		System.out.println("Name:"+name);
		System.out.println("Id:"+eid);
		System.out.println("Location:"+address);
		System.out.println("Experience:"+exp);
	}

}
