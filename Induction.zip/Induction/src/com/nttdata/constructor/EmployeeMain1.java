package com.nttdata.constructor;

public class EmployeeMain1 {

	public static void main(String[] args) {
		Employee1 e = new Employee1(103,"Rohan","Bangalore",4.5f);
		e.dispData();

	}

}
