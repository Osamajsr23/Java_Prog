package com.nttdata.task;

public class OperationMain {

	public static void main(String[] args) {
		
		Operation o = new Operation();
		o.addition();
		o.substraction();
		o.multiplication();
		
	}

}
