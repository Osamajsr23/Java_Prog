package com.nttdata.task;
import java.util.Scanner;
public class Operation {
	int a,b;	
	
	void addition() {
		System.out.println("Enter number a and b:");
		Scanner sc = new Scanner(System.in);

		a=sc.nextInt();
		b=sc.nextInt();
		System.out.println("addition of a and b is:"+(a+b));
		}
	void substraction() {
		System.out.println("Enter number a and b:");
		Scanner sc = new Scanner(System.in);

		a=sc.nextInt();
		b=sc.nextInt();
		System.out.println("substraction of a and b is:"+(a-b));
		}
	void multiplication() {
		System.out.println("Enter number a and b:");
		Scanner sc = new Scanner(System.in);

		a=sc.nextInt();
		b=sc.nextInt();
		System.out.println("multiplication of a and b is:"+(a*b));
		}
}