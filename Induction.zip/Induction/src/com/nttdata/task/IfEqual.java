package com.nttdata.task;
import java.util.Scanner;
public class IfEqual {

	public static void main(String[] args) {
		int n1,n2,n3,n4;
		System.out.println("Enter four numbers:");
		Scanner sc = new Scanner(System.in);
		
		n1 = sc.nextInt();
		n2=sc.nextInt();
		n3=sc.nextInt();
		n4=sc.nextInt();
		
		if(n1==n2&&n2==n3&&n3==n4&&n4==n1) {
			System.out.println("All four numbers are equal");
		}
		else {
			System.out.println("All four numbers are not equal");
		}
	}

}
