package com.nttdata.task;
import java.util.*;
public class PNnumber {

	public static void main(String[] args) {
		int num;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter a number");
		num = sc.nextInt();
		if(num>0)
		{
			System.out.println("number is positive");
		}
		else
		{
			System.out.println("number is negative");
		}
		
	}

}
