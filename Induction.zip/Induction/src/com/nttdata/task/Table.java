package com.nttdata.task;

public class Table {

	public static void main(String[] args) {
		int a=2;
		int n;
		for(int i=1;i<=10;i++) {
			
			System.out.println(n=a*i);
		}
			
	}

}
