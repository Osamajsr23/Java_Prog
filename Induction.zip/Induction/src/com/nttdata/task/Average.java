package com.nttdata.task;
import java.util.Scanner;
public class Average {

	public static void main(String[] args) {
		int avg;
		int n,a,b,c;
		Scanner s = new Scanner(System.in);
		/*System.out.println("Enter the number of values:");
		n= s.nextInt();*/
		System.out.println("Enter the three numbers:");
		a=s.nextInt();
		b=s.nextInt();
		c=s.nextInt();
		avg=(a+b+c)/3;
		
		System.out.println("Average of three numbers:"+avg);
		
		
	}

}
