package com.nttdata.exception;

public class StringCount {
	int len;
	void count(String str)
	{
		try {
			if(str == "null")
			{
				throw new ArithmeticException("String contains null value");
			}
			else {
				System.out.println(str.length());
			}
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
	}
}
