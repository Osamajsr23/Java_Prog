package com.nttdata.exception;

//voter exception is exception class
public class VoterException extends Exception {
	
	VoterException(String msg)
	{
		super(msg);
	}
	VoterException(String msg, Throwable cause)
	{
		super(msg,cause);
	}
		
}
