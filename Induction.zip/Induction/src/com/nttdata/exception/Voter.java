package com.nttdata.exception;

public class Voter {
	
	void VoterAge(int age) throws VoterException
	{
		if(age<18)
		{
			throw new VoterException("Voter is not eligible for vote");
		}
		else
		{
			System.out.println("Welcome to vote");
		}
	}
}
