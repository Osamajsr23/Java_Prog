package com.nttdata.exception;

import java.io.File;
import java.io.IOException;
public class FileDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file = new File("First.txt");
		System.out.println("file is existing :"+file.exists());
		
		try {
			file.createNewFile();
		}
		catch(IOException e){
			System.out.println(e);
		}
		System.out.println("file is existing : "+file.exists());
	}

}
