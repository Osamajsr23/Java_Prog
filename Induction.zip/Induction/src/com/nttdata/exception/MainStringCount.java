package com.nttdata.exception;

public class MainStringCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringCount sc = new StringCount();
		sc.count("Richa");
		sc.count("null");
		sc.count("Richa Singh");
	}

}
