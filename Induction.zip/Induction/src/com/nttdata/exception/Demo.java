package com.nttdata.exception;
import java.util.Scanner;
public class Demo {
	void demo()
	{
		 int num1,num2,res;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 2 no.");
		num1=sc.nextInt();
		num2=sc.nextInt();
		try {
			res=num1/num2;
			System.out.println("Result: "+res);
		}
		catch(ArithmeticException ae)
		{
			System.out.println(ae);
		}
		System.out.println("end of the code");
	}
}
