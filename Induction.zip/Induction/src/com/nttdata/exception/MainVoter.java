package com.nttdata.exception;

public class MainVoter {

	public static void main(String[] args) {
		Voter voter=new Voter();
		try {
			voter.VoterAge(17);
		} catch (VoterException e) {
			System.out.println(e);
		}
		
		try {
			voter.VoterAge(18);
		} catch (VoterException e) {
			System.out.println(e);
		}
		try {
			voter.VoterAge(20);
		} catch (VoterException e) {
			System.out.println(e);
		}
		
		
		
	}

}
