package com.nttdata.exception;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo d = new Demo();
		d.demo();
	}

}
