package com.nttdata.array;

public class FinallyMainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DemoFinally df = new DemoFinally();
		df.demo();
		
	}

}
