package com.nttdata.array;

public class DemoFinally {
	void demo() {
		
		try {
			int res = 10/0;
			System.out.println(res);
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		finally
		{
			System.out.println("always executes");
		}
		System.out.println("rest of the code");
		
		
	}
}
