package com.nttdata.array;

public class Demo1Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo1 d1 = new Demo1();
		d1.demo();
	}

}
