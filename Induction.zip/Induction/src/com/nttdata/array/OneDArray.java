package com.nttdata.array;
import java.util.Scanner;
public class OneDArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int a[];
		int i;
		//a = new int[4];
		int a[] = new int[5];
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the 5 values:");
		for(i=0;i<5;i++)
		{
			a[i]=s.nextInt();
		}
		for(i=0;i<5;i++)
		{
			System.out.println("values of array are: "+a[i]);
		}
	}

}
