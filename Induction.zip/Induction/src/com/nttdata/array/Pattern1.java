package com.nttdata.array;

public class Pattern1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j;
		for(i=0;i<5;i++)
		{
			for(j=0;j<5;j++)
			{
				System.out.print('*');
			}
			System.out.println();
		}
	}

}
