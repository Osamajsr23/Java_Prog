package com.nttdata.array;
import java.util.Scanner;
public class TwoDArray {

	public static void main(String[] args) {
		int i,j;
		//int a[][];
		//a= new int[2][2];
		int a[][]= new int[2][2];
		System.out.println(" Enter the values of array:");
		Scanner s = new Scanner(System.in);
		for(i=0;i<2;i++)
		{
			for(j=0;j<2;j++)
			{
				a[i][j]=s.nextInt();
			}
			
		}
		System.out.println("Values of array are:");
		for(i=0;i<2;i++)
		{
			for(j=0;j<2;j++)
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}

	}

}
