package com.nttdata.array;

public class MainSingle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		School school = new School();
		school.dispArray();
	} 

}
