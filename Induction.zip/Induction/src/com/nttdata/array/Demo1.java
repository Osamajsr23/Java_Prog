package com.nttdata.array;

public class Demo1 {
	void demo(){
	int arr[]= {1,2,3,0,5,6};
	try {
		try {
			arr[6]=4;
			for(int a : arr)
			{
				System.out.println(a);
			}
		}
		catch(ArithmeticException ae)
		{
			System.out.println(ae);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		int res = arr[2]/arr[3]; //3/0 --AE
	}
	
	catch(Exception e)
	{
		System.out.println(e);
	}
	System.out.println("end of code");
	
	}
}
