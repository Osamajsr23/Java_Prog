package com.nttdata.array;

public class School {

	String name= "KVN";
	int sid = 1001;
	int sno=1000;
	String sub_name[]= {"English","Hindi","Science","SST","Sanskrit","Maths"};
	
	void dispArray() {
		System.out.println("School name"+name);
		System.out.println("Number of students:"+sno);
		System.out.println("school id:"+sid);
		
		/*for(int i=0;i<sub_name.length;i++) {
			//System.out.println("Subject name:"+sub_name[i]);
		}*/
		//Enhanced for loop
		
		for(String subject:sub_name)
		{
			System.out.println("Subject Name :"+subject);
		}
	
	}
}
