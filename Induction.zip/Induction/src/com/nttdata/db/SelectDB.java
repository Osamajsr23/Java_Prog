package com.nttdata.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;



public class SelectDB {

	public static void main(String[] args) {
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");//driver name	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/TRDB","root","Manju1234#@"); //drivermanager is classname, all other are interface
			Statement stmt= con.createStatement();
			
			ResultSet rs= stmt.executeQuery("select * from suppliers");
			ResultSetMetaData rm = rs.getMetaData();
			System.out.println(rm.getColumnName(1)+"\t"+rm.getColumnName(2)+"\t"+rm.getColumnName(3)+"\t"+rm.getColumnName(4));
			while(rs.next())
			{
				//System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getString("status")+"\t"+rs.getString(4)+"\t");
				System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getInt(3)+"\t"+rs.getString(4));
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}


	}

}
