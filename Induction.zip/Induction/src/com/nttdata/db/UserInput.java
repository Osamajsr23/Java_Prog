package com.nttdata.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class UserInput {

	public static void main(String[] args) {
		try
		{
			int no,status;
			String name,city;			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter supplier number");
			no=sc.nextInt();
			System.out.println("Enter the supplier status");
			status=sc.nextInt();
			System.out.println("Enter supplier name");
			name=sc.next();
			System.out.println("Enter city");
			city=sc.next();
			
			Class.forName("com.mysql.cj.jdbc.Driver");//driver name	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/TRDB","root","Manju1234#@");
			PreparedStatement stmt= con.prepareStatement("Insert into suppliers(sno,sname,city,status) values (?,?,?,?)");
			
			stmt.setInt(1, no);//setInt - integer i/p with 2 para-(column number, value)
			stmt.setString(2, name);
			stmt.setInt(4, status);
			stmt.setString(3, city);
						
			stmt.executeUpdate();	
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println("Code executed");


	}

}
