package com.nttdata.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class InsertData {

	public static void main(String[] args) {
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");//driver name	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/TRDB","root","Manju1234#@");
			Statement stmt= con.createStatement();
			stmt.executeUpdate("insert into suppliers values(6,'STEST',100,'TEST CITY')");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println("Code executed");

	}

}
