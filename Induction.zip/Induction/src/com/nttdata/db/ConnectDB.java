package com.nttdata.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectDB {

	public static void main(String[] args) {
		 
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");//driver name			
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
		try 
		{
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/TRDB","root","Manju1234#@");
			if(con!=null)
			{
				System.out.println("Connected with DB");
			}
			else
			{
				System.out.println("Not connected");
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}

	}

}
