package com.nttdata.db;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class UpdateDB {

public static void main(String[] args) {
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");//driver name
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/TRDB","root","Manju1234#@");
			Statement stmt= con.createStatement();
			stmt.executeUpdate("update suppliers set status=5 where sno = 101");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}