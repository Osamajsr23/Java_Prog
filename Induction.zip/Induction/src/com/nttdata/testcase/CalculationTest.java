package com.nttdata.testcase;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculationTest {
	Calculation calc = new Calculation();

	@Test
	public void testAdditon() {
		int expected = 22;
		int actual = calc.additon(12, 10);
		assertEquals(expected, actual); //boolean
	}

	@Test
	public void testSubstraction() {
		int expected = 2;
		int actual = calc.substraction(12, 10);
		assertEquals(expected, actual); //boolean
	}

}
