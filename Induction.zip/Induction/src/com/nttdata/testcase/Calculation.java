package com.nttdata.testcase;

public class Calculation {
	int additon(int a, int b)
	{
		return a+b;
	}
	int substraction(int a, int b)
	{
		return a-b;
	}
}
