package com.nttdata.staticdemo;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			Employee emp1 = new Employee(101, "First");
			Employee emp2 = new Employee(102, "Second");
			Employee emp3 = new Employee(103, "Third");
			
			emp1.display();
			emp2.display();
			emp3.display();
			
			System.out.println("Company : "+Employee.company);
					
		

	}

}
