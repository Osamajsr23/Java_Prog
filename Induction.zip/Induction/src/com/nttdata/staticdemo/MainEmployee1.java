package com.nttdata.staticdemo;

public class MainEmployee1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			Employee emp1 = new Employee(101, "First");
			Employee emp2 = new Employee(102, "Second");
			Employee emp3 = new Employee(103, "Third");
			
			
			emp1.display();//gds
			
			emp3.display();//ips
			
				
			emp2.display();//ips
			Employee1.changeBranch(); 					
		

	}

}
