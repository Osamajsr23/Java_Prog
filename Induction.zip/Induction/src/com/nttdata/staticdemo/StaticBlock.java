package com.nttdata.staticdemo;

public class StaticBlock {

		static 
		{
			System.out.println("1. first static block");
		}
		StaticBlock()
		{
			System.out.println("6. constructor");
		}
		static {
			System.out.println("2. second static block");
		}
		void method()
		{
			System.out.println("7. method");
		}
		static
		{
			System.out.println("3. third static block");
		}
		public static void main(String[] args)
		{
			System.out.println("5. inside main");
			StaticBlock sb = new StaticBlock();
			sb.method();
			System.out.println("8. end of main");
		}
		static {
			System.out.println("4. fourth static block");
		}
		
	}

