package com.nttdata.staticdemo;

public class Employee1 {
	int id;
	String name;
	static String company = "NTT Data GDS";
	
	public Employee1(int id, String name) {
		this.id = id;
		this.name = name;
	}
	static void changeBranch()
	{
		company = "NTT Data IPS";
	}
	void display()
	{
		System.out.println("Employee id : "+id);
		System.out.println("Employee Name : "+name);
		System.out.println("Employee Branch : "+company);
	}

}
