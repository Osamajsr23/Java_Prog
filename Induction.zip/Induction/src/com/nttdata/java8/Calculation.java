package com.nttdata.java8;

public interface Calculation {
	int calc(int num1, int num2);
}
