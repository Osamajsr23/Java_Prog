package com.nttdata.java8;

public interface MethodRef {
	void message(); //258570
}
