package com.nttdata.java8;

public class MyMethodRef {
	
	//to work with interface method make this method as public and static type
	public static void dispMessage()
	{
		System.out.println("Hello word..!!");//renu maharana
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodRef ref = MyMethodRef :: dispMessage;//referring this method to interface
		ref.message();
	}

}
