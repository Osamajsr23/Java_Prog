package com.nttdata.java8;

public class MyCalculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculation cal= (int a, int b)->a*b;
		
	}	

}
