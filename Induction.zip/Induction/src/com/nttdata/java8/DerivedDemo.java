package com.nttdata.java8;

public class DerivedDemo implements Demo {

	@Override
	public void meth() {
		// TODO Auto-generated method stub
		System.out.println("inside the subclass");
	}
	
}
