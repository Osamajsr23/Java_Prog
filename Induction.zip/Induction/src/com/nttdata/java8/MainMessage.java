package com.nttdata.java8;

public class MainMessage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Message var=()->System.out.println("Hello world..!!");
		
		var.msg();
	}

}
