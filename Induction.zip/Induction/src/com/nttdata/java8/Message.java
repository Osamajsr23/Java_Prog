package com.nttdata.java8;

public interface Message {
	void msg();
}
