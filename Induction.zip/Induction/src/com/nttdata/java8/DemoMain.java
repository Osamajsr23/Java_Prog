package com.nttdata.java8;

public class DemoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DerivedDemo dd = new DerivedDemo();
		dd.disp();
		dd.meth();
	}

}
