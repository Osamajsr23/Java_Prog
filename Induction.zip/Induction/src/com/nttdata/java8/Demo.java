package com.nttdata.java8;

public interface Demo {
	default void disp()
	{
		System.out.println("in interface");
	}
	void meth();
}
