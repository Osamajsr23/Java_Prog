package com.nttdata.java8;

public class MainArea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Area square =(int s)-> {
			int result = s*s;
			return result;
		};
		int sarea = square.area(67);
		System.out.println("area of square: "+sarea);
		
	}

}
