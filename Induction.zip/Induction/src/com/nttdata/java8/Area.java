 package com.nttdata.java8;
@FunctionalInterface

public interface Area {
  int area(int s);
}
