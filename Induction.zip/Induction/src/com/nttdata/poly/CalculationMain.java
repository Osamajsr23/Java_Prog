package com.nttdata.poly;

public class CalculationMain {

	public static void main(String[] args) {
		Calculation c = new Calculation();
		c.calc(12);
		c.calc(2,3);
		c.calc(2.2f, 2);
		c.calc(2, 2.3f);
	}

}
