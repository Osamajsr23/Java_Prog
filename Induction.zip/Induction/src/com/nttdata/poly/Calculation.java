package com.nttdata.poly;

public class Calculation {
	float result;
	
	void calc(int num)
	{
		result= num*1.5f;
		System.out.println("Result: "+result);
	}
	void calc(int num1, int num2)
	{
		result=num1+num2;
		System.out.println("Result :"+result);
	}
	void calc(int num1, float num2)
	{
		result=num1*num2;
		System.out.println("Result:"+result);
	}
	void calc(float num2, int num1)
	{
		result=num1+num2;
		System.out.println("Result: "+result);
	}
}
