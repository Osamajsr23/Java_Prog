package com.nttdata.poly;

public class ConstructorOverloadingMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConstructorOverloading c =new ConstructorOverloading(2);
		ConstructorOverloading c1 = new ConstructorOverloading(2,2);
		ConstructorOverloading c2 = new ConstructorOverloading(2,1.1f);
		ConstructorOverloading c3 = new ConstructorOverloading(1.1f,2);
		ConstructorOverloading c4 = new ConstructorOverloading(1.1f,1.1f);
		
	}

}
