package com.nttdata.poly;

public class ConstructorOverMain {

	public static void main(String[] args) {
		
		
		
			ConstructorOver c =new ConstructorOver(1,"Renu","Nashik");
			ConstructorOver c1= new ConstructorOver(2,"Rahul");
			ConstructorOver c2 = new ConstructorOver("Nikhil",3);
			ConstructorOver c3 = new ConstructorOver("Neeta","Nashik");
			ConstructorOver c4 = new ConstructorOver(4);	
		
				c.display();
				c1.display();
				c2.display();
				c3.display();
				c4.display();
		
		
	}

}
