package com.nttdata.poly;

public class ConstructorOverloading {
	float result;
	ConstructorOverloading(int a)
	{
		result= a*1.2f;
		System.out.println("Result:"+result);
	}
	ConstructorOverloading(int a, int b)
	{
		result=a*b;
		System.out.println("Result:"+result);
	}
	ConstructorOverloading(int a,float b)
	{
		result=a*b;
		System.out.println("Result:"+result);
	}
	ConstructorOverloading(float a,int b)
	{
		result=a*b;
		System.out.println("Result:"+result);
	}
	ConstructorOverloading(float a,float b)
	{
		result=a*b;
		System.out.println("Result:"+result);
	}
}
