package com.nttdata.poly;

public class ConstructorOver {

	int id;
	String name;
	String address;
	
	 ConstructorOver(int id, String name, String address)
	 {
		 this.id=id;
		 this.name=name;
		 this.address=address;
	 }
	 ConstructorOver(int id, String name)
	 {
		 this.id=id;
		 this.name=name;
		 address="delhi";
	 }
	 ConstructorOver(String name, int id)
	 {
		 this.name=name;
		 this.id=id;
		 address="mumbai";
	 }
	 ConstructorOver(String name, String address)
	 {
		 id=12;
		 this.name=name;
		 this.address=address;
	 }
	 ConstructorOver(int id)
	 {
		 this.id=id;
		 name="Ashwini";
		 address="Dindori";
	 }
	 void display()
	 {
		System.out.println("employee id:"+id);
		System.out.println("employee name:"+name);
		System.out.println("employee address:"+address);
	 }
	
}
