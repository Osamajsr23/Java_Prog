package com.nttdata.test1;
import java.util.Scanner;
public class EmployeeMain {

	public static void main(String[] args) {
		
			Employee totalSalary=new Employee();
			Scanner sc = new Scanner(System.in);
			
			
			System.out.println("Enter Permanent Emp's Basic Salary ");
			System.out.println();
			double pbasic=sc.nextDouble();
			System.out.println();
			
			System.out.println("Enter Permanent Emp's Hra !");
			System.out.println();
			double phra=sc.nextDouble();
			System.out.println();
			
			//PermanentEmp psal=totalSalary.new PermanentEmp(pbasic, phra);
			
			//psal.permaEmpTotalSal();
			
			System.out.println();
			System.out.println("________________");
			System.out.println();
			
			
			
			System.out.println("Enter Contract Emp's Basic Salary ");
			System.out.println();
			double cbasic=sc.nextDouble();
			System.out.println();
			
			System.out.println("Enter Contract Emp's Hra !");
			System.out.println();
			double chra=sc.nextDouble();
			System.out.println();
			System.out.println();
			//ContractEmp csal=totalSalary.new ContractEmp(cbasic, chra);
			//csal.contractEmpTotalSal();
		
		
	}
	

	}


