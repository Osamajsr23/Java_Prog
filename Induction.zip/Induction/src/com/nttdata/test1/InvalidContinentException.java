package com.nttdata.test1;

public class InvalidContinentException extends Exception {
	InvalidContinentException(String msg)
	{
		super(msg);
	}
	InvalidContinentException(String msg, Throwable cause)
	{
		super(msg,cause);
	}
}
