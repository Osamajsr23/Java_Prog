package com.nttdata.test1;
import java.util.Scanner;

public class Employee {
		double netSalary;
		double basicSalary;
		double hra;
		double pf;
		
		class PermanentEmp{
					
			public PermanentEmp(double basicSall, double hraa) {
						
				basicSalary = basicSall;
				hra = hraa;
				pf = (basicSalary*12)/100;
						
				}
					
				public void permaEmpTotalSal() {
						
					netSalary=basicSalary+hra+5000.00-pf;
						
					System.out.println("Permanent Emp's Total  Salary is Rs: "+netSalary+"/-");
						
					}
					
			}
		//Contract Emp
		
		class ContractEmp{
			
	
			public ContractEmp(double basicSall, double hraa) {
				
					basicSalary = basicSall;
					hra = hraa;
				
					pf = (basicSalary*12)/100;
				
			}
			
			public void contractEmpTotalSal() {
				
				netSalary=basicSalary+hra+2500.00-pf;
				
				System.out.println("Contract Emp's Total  Salary is Rs: "+netSalary+"/-");
				
			}
			
			
		}

		
}
