package com.nttdata.test1;

import com.nttdata.exception.Voter;
import com.nttdata.exception.VoterException;

public class MapDemoMain {

	public static void main(String[] args) {
		
		MapDemo d = new MapDemo();
		
		
		try {
			d.continentDetails();
		} 
		catch (InvalidContinentException e) {
			
			System.out.println(e);
		}
	}
}
