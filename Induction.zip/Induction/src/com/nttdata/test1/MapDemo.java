package com.nttdata.test1;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapDemo {

	void continentDetails() throws InvalidContinentException
	{
		
				LinkedHashMap<String, LinkedHashMap<String,String>> countryMap = new LinkedHashMap<String, LinkedHashMap<String,String>>(); //map inside the map
				
				countryMap.put("Asia", new LinkedHashMap<String, String>()); //for first map initialized the value of string as Asia  a
				
				//and second para - object of map
				
				countryMap.get("Asia").put("India", "Delhi"); //storing the value of second parameter, for linking 1st para to 2nd para we have to use get()
				countryMap.get("Asia").put("China", "Beijing");
				countryMap.get("Asia").put("South Korea", "Seoul");
				
				countryMap.put("Africa", new LinkedHashMap<String, String>());
				
				countryMap.get("Africa").put("Kenya","Nairobi");
				countryMap.get("Africa").put("Madagaskar", "Antananarivo");
				countryMap.get("Africa").put("Zimbabwe", "Harare");
				
				countryMap.put("Europe", new LinkedHashMap<String, String>());
				
				countryMap.get("Europe").put("France","Paris");
				countryMap.get("Europe").put("Germany", "Berlin");
				countryMap.get("Europe").put("Italy", "Rome");
				
				for(Map.Entry entry : countryMap.entrySet())
				{
					System.out.println(entry.getKey()+" "+entry.getValue());
				}
	}
}
