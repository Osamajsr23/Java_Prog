package com.nttdata.nested;

public class Outer {
	int num1=10;
	private int num2=20;
	static int num3=30;
	
	static class Nested
	{
		private int num4=40;
		int num5=50;
		
		void dispData()
		{
			Outer outer = new Outer();
			System.out.println("Num1: "+outer.num1);
			System.out.println("Num2: "+outer.num2);
			System.out.println("num3: "+num3);
			System.out.println("num4: "+num4);
			System.out.println("num5: "+num5);
		}
	}
	Nested nested = new Nested();
	void outerDisp()
	{
		System.out.println("Num4 in outer class : "+nested.num4);
	}	
	/*public static void main(String[] args)
	{
		Outer outer1 = new Outer();
		
		Nested nested1 = new Nested();
		
		System.out.println("num1: "+outer1.num1);
	}
	*/

}
