package com.nttdata.nested;


public class IOuter {
	int num1=10;
	private int num2=20;
	
	class Inner{
		private int num3=30;
		int num4=40;
		
		void dispInner()
		{
			System.out.println("Num1 in inner: "+num1);
			System.out.println("Num2: "+num2);
			System.out.println("Num3: "+num3);
			System.out.println("Num4: "+num4);
		}
	}
	void dispOuter()
	{
		System.out.println("Num1: "+num1);
		Inner inner = new Inner();
		System.out.println("num3 in outer: "+inner.num3);
		System.out.println("num4 in outer: "+inner.num4);
	}
}
