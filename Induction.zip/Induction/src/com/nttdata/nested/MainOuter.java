package com.nttdata.nested;

import com.nttdata.nested.Outer.Nested;

public class MainOuter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Outer outer1 = new Outer();
		
		Nested nested1 = new Nested();
		
		System.out.println("num1: "+outer1.num1);
		System.out.println("num5: "+nested1.num5);
		//System.out.println("num4: "+Outer.Nested.num4);
		outer1.outerDisp();
		nested1.dispData();
	}

}
