package com.nttdata.nested;
//import com.nttdata.nested.IOuter.Inner;
public class MainIOuter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//OuterClassName
		IOuter iout = new IOuter();
		
		IOuter.Inner inner1 = iout.new Inner();
		iout.dispOuter();
		inner1.dispInner();
	}

}
