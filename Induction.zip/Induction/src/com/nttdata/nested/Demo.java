package com.nttdata.nested;

public class Demo {
	
	Demo(int num)//90
	{
		System.out.println("First : "+num);
	}
	Demo(int num1, int num2 )//20 90
	{
		this(num2); //this(num1)num1=num2=90
		System.out.println("Second: "+num1 + " "+num2);
	}
	Demo(int num1, int num2, int num3)//10, 20, 30
	{
		this(num2,90); //this(num1,num2) num1=num2, num2=90
		System.out.println("Third: "+num1+" "+num2+" "+num3);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo ob = new Demo(10,20,30);
	}

}
