package com.nttdata.collection;

import java.util.LinkedHashMap;
import java.util.Map;

public class Album 
	{
		void albumDetails()
		{
			LinkedHashMap<String, LinkedHashMap<String,Integer>> album = new LinkedHashMap<String, LinkedHashMap<String,Integer>>(); //map inside the map
			
			album.put("Singer1", new LinkedHashMap<String, Integer>()); //for first map initialized the value of string as singer1 a
			
			//and second para - object of map
			
			album.get("Singer1").put("Album1", 100); //storing the value of second parameter, for linking 1st para to 2nd para we have to use get()
			album.get("Singer1").put("Album2", 150);
			album.get("Singer1").put("Album3", 200);
			
			album.put("Singer2", new LinkedHashMap<String, Integer>());
			
			album.get("Singer2").put("Album1", 130);
			album.get("Singer2").put("Album2", 150);
			album.get("Singer2").put("Album3", 220);
			
			for(Map.Entry entry : album.entrySet())
			{
				System.out.println(entry.getKey()+" "+entry.getValue());
			}
		}
}
