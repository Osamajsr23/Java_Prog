package com.nttdata.collection;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashSetDemo {

		void set()
		{
			// stores the data in insertion order and it works with distinct value
			LinkedHashSet<Integer> hs = new LinkedHashSet<Integer>();
			hs.add(101);
			hs.add(78); 
			hs.add(67);
			hs.add(34);
			hs.add(89);
			hs.add(78);
			
			Iterator<Integer> itr = hs.iterator();
			while(itr.hasNext())
			{
				System.out.println(itr.next());
			}
			
		}
}
