package com.nttdata.collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HashMapDemo {
	void map()
	{
		// Key-distinct value-can be repeated, does not contain any sequence
		HashMap<Integer, String> hm =new HashMap<Integer, String>();
		hm.put(101, "Harry");
		hm.put(102, "Rohn");
		hm.put(171, "James");
		hm.put(102, "Jabby");
		hm.put(25, "Harry");
		hm.put(109, "John");
		
		//convert Map data into Set
		Set set = hm.entrySet(); //all the data of hm will be stared into set
		Iterator itr = set.iterator();
		
		while(itr.hasNext())
		{			//System.out.println(itr.next()); key=value
			
			Map.Entry entry = (Map.Entry)itr.next(); // access key and value separately | we have converted all itr data to map.entry type
			
			System.out.println(entry.getKey() +" "+entry.getValue());			
		}
		
		for(Map.Entry entry : hm.entrySet())
		{
			System.out.println(entry.getKey() +" "+entry.getValue());
		}

	}

}
