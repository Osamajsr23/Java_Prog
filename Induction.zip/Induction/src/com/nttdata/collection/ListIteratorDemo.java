package com.nttdata.collection;

import java.util.ArrayList;
import java.util.ListIterator;

public class ListIteratorDemo {
	public static void main(String[] args) {
		
		ArrayList<Integer> al = new ArrayList<Integer>();
		
		al.add(23);
		al.add(89);
		al.add(56);
		al.add(1);
		
		ListIterator<Integer> litr = al.listIterator();
		 while(litr.hasNext())
		 {
			 litr.next();
		 }
		 while(litr.hasPrevious())
		 {
			 System.out.println(litr.previous());
			 
		 }
		 System.out.println("end of statement");
		
	}
}
