package com.nttdata.collection;

public class MainListDemo {

	public static void main(String[] args) {
		ListDemo ld = new ListDemo();
		
		ld.list();
		

	}

}
