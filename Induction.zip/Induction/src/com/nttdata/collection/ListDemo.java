package com.nttdata.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
public class ListDemo {
	void list()
	{
		ArrayList<Integer> al = new ArrayList<Integer>();
		
		//store the value in array list
		
		al.add(7);
		al.add(5);
		al.add(3);
		al.add(5);
		al.add(4);
		
		//Collections.sort(al);// sorting  al data
		//System.out.println(al); //display the list
		
		//System.out.println();
		
		List<Integer> li =new ArrayList<Integer>(); //second list
		
		li.add(3);
		li.add(8);
		li.add(21);
		li.add(90);
		
		al.addAll(li); //li data will store in al
		
//		for(int i=0;i<al.size();i++)
//		{
//			System.out.println(al.get(i));
//		}
//		
//		System.out.println();
//		for(Integer lists :al)
//		{
//			System.out.println(lists);
//		}
		
		Iterator<Integer> itr= al.iterator();
		
		while(itr.hasNext()) // checking itr contains any data or not
		{
			System.out.println(itr.next());// its displaying itr value and then it is moving to the next data
		}

	}
}
