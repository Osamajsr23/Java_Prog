package com.nttdata.collection;

import java.util.ArrayList;

import java.util.Iterator;

public class EmployeeMain {

	public static void main(String[] args) {
		/*Employee emp1 = new Employee(101, "John", 1.2f);
		Employee emp2 = new Employee(102, "Harry", 2.7f);
		Employee emp3 = new Employee(103, "Rohn", 8.0f);
		Employee emp4 = new Employee(104, "James", 8.1f);
		
		ArrayList<Employee> list = new ArrayList<Employee>();
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);
		list.add(emp4);*/
		
		ArrayList<Employee> list = new ArrayList<Employee>();
		list.add(new Employee(101, "John", 1.2f));
		list.add(new Employee(102, "Harry", 2.7f));
		
		Iterator< Employee> itr =list.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}


	}

}
