package com.nttdata.collection;

public class HashMapMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMapDemo hd = new HashMapDemo();
		hd.map();
	}

}
