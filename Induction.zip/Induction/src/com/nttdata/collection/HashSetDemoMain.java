package com.nttdata.collection;

public class HashSetDemoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//HashSetDemo hd = new HashSetDemo(); //object of hashsetdemo
		//hd.set();
		
		HashSetDemoSort hds = new  HashSetDemoSort(); //object of hashsetdemosort
		hds.set1();
	}

}
