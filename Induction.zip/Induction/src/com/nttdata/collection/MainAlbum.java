package com.nttdata.collection;

public class MainAlbum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Album map = new Album();
		map.albumDetails();
	}

}
