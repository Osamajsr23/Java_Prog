package com.nttdata.collection;

public class Employee {
	 int id;
	 String name;
	 float exp;
	 
	 public Employee(int id, String name, float exp) {
			this.id = id;
			this.name = name;
			this.exp = exp;
		}
		@Override
		public String toString() {
			return "Employee [id=" + id + ", name=" + name + ", exp=" + exp + "]";
		}

}
