package com.nttdata.collection;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetDemo {
	
	void set()
	{
		// not in order and it works with distinct value
		HashSet<Integer> hs = new HashSet<Integer>();
		hs.add(101);
		hs.add(78);
		hs.add(34);
		hs.add(67);
		hs.add(78);
		hs.add(89);
		
		Iterator<Integer> itr =hs.iterator();
		while (itr.hasNext()) 
		{
			System.out.println(itr.next());
			
		}
	}

}
