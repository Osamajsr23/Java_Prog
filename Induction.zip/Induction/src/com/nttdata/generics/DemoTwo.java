package com.nttdata.generics;

public class DemoTwo<t1,t2> {
	t1 val1;
	t2 val2;
	
	DemoTwo(t1 para1, t2 para2)
	{
		val1 = para1;
		val2 = para2;
	}
	void disp()
	{
		System.out.println("First value: "+val1+"\t");
		System.out.println("Second value: "+val2);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DemoTwo<String, Character> one = new DemoTwo<String, Character>("first",'s');
		DemoTwo<Integer, Float> two = new DemoTwo<Integer, Float>(12,2.3f);
		
		one.disp();
		two.disp();
	}

}
