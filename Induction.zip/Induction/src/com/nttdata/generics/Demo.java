package com.nttdata.generics;

public class Demo <t> {
	
	t val1;
	t val2;
	Demo(t para1, t para2)
	{
		val1=para1;
		val2=para2;
	}
	void disp()
	{
		System.out.println("first value: "+val1 +"\t");
		System.out.println("Second value: "+val2);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo<String> one = new Demo<String>("Renu","Maharana");
		Demo<Integer> two =  new Demo<Integer>(12,6);
		Demo<Double> three = new Demo<Double>(12.3,34.2);
		Demo<Character> four = new Demo<Character>('1','2');
		
		one.disp();
		two.disp();
		three.disp();
		four.disp();
		
		
	}

}
