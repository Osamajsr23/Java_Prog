package com.nttdata.generics;

public class DemoOne <t> {

		t val; //t- unknown data type
		DemoOne(t para)
		{
			val=para;
		}
		void disp()
		{
			System.out.println("Value :"+val);
		}
	public static void main(String[] args) {
		DemoOne<String> one = new DemoOne<String>("Renu");
		DemoOne<Integer> two = new DemoOne<Integer>(12);
		DemoOne<Double> three = new DemoOne<Double>(12.2);
		DemoOne<Character> four = new DemoOne<Character>('a');
		one.disp();
		two.disp();
		three.disp();
		four.disp();
	}

}
