package com.nttdata.test2;

public class Maintask {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RenuMaharana_258570 rm = new RenuMaharana_258570();
		
	}

}
