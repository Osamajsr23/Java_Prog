package com.nttdata.test2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class RenuMaharana_258570 {
	public static void main(String[] args) {
		int choose;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any number(1 t0 4) to do different operation:");
		System.out.println("1. array list, 2. Hash map 3. treemap 4.exist ");
		choose=sc.nextInt();
		
		switch(choose) {
		case 1:
			System.out.println("Array list");
			ArrayList<String> al = new ArrayList<String>();
			for(int i=0; i<5;i++)
			{
				al.add(sc.next());
			}
			Collections.sort(al);
		
			
			Iterator<String> itr= al.iterator();
			
			while(itr.hasNext()) // checking itr contains any data or not
			{
				System.out.println(itr.next());// its displaying itr value and then it is moving to the next data
			}
			break;
		case 2:
			System.out.println("Hash map");
			HashMap<Integer, String> hm =new HashMap<Integer, String>();
			
			for(int i=0; i<5;i++)
			{
				hm.put(sc.nextInt(), sc.next());
			}
			Set set = hm.entrySet(); //all the data of hm will be stared into set
			
			 //Collections.sort(set);
			Iterator itr1 = set.iterator();
			
			while(itr1.hasNext())
			{			//System.out.println(itr.next()); key=value
				
				Map.Entry entry = (Map.Entry)itr1.next(); // access key and value separately | we have converted all itr data to map.entry type
				
				System.out.println(entry.getKey() +" "+entry.getValue());			
			}
			break;
		case 3:
			System.out.println("Tree map");
			TreeMap<Integer, String> tm =new TreeMap<Integer, String>();
			
			for(int i=0; i<5;i++)
			{
				tm.put(sc.nextInt(), sc.next());
			}
			Set set1 = tm.entrySet(); //all the data of hm will be stared into set
			
			// Collections.sort(set);
			Iterator itr2 = set1.iterator();
			
			while(itr2.hasNext())
			{			//System.out.println(itr.next()); key=value
				
				Map.Entry entry = (Map.Entry)itr2.next(); // access key and value separately | we have converted all itr data to map.entry type
				
				System.out.println(entry.getKey() +" "+entry.getValue());			
			}
			break;
		case 4:
			System.out.println("exist");
			break;
	
		
		}
		
	}
	
}
