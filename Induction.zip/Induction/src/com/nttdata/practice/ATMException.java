package com.nttdata.practice;

public class ATMException extends Exception {
	
	ATMException(String msg)
	{
		super(msg);
	}
	

}
