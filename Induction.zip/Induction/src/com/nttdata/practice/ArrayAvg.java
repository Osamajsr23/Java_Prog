package com.nttdata.practice;

public class ArrayAvg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {1,4,3,6,3,5};
		float avg;
		int sum=0;
		int n=a.length;
		
		for(int i=0;i<a.length;i++)
			sum=a[i]+sum;

		avg=sum/n;
		System.out.println("Average: "+avg);
	}
	}


