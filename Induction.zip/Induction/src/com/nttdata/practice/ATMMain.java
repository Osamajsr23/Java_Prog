package com.nttdata.practice;

public class ATMMain {

	public static void main(String[] args) {
		
		
		InvalidAmountException deposit1 = new InvalidAmountException();
		InsufficientFundsException fund = new InsufficientFundsException();
		
		try {
			
			deposit1.deposit(400);
		}
		catch(ATMException e)
		{
			System.out.println("Exception caught");
			System.out.println(e.getMessage());
		}
		try {
			fund.withdrawl(500);
		}
		catch(ATMException e)
		{
			System.out.println("Exception caught");
			System.out.println(e.getMessage());
		}
		
	}

}
