package com.nttdata.practice;

public class InsufficientFundsException {
	
	void withdrawl(int amount) throws ATMException
	{
		if( amount <=0 || amount <=100)
		{
			throw new ATMException("ATM does'nt have sufficient amount");
		}
		else {
			System.out.println("withdrawl approved");
		}
	}
}
