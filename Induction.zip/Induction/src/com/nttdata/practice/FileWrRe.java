package com.nttdata.practice;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class FileWrRe {
	
	public static void main(String[] args) {

		try {
			FileWriter writer = new FileWriter("MyFile1.txt",true);
			writer.write("hello ash"+"\n");
			writer.write("how are you?");
			writer.close();
		
			FileReader reader = new FileReader("MyFile1.txt");
			int character;
			
		while((character = reader.read())!=-1)
		{
				System.out.println((char)character);
			}
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
	}

	
}
