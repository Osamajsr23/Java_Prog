package com.nttdata.practice;



public class InvalidAmountException {

		void deposit(int amount) throws ATMException
		{
			if( amount <=0 || amount <500)
			{
				throw new ATMException("Invalid deposit.. please enter valid amount");
			}
			else {
				System.out.println("You have put valid amount please click on deposit");
			}
		}
	
}
