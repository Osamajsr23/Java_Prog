package com.nttdata.abstractdemo;

public class MainShape {

	public static void main(String[] args) {
		Triangle t = new Triangle();
		t.myTriangle();
		t.area(10);
		t.triangle();
	}

}
