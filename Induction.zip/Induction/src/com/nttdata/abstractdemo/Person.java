package com.nttdata.abstractdemo;
import java.util.Scanner;
abstract public class Person {
	Scanner sc = new Scanner(System.in);
	
	abstract void details(String name, int pid);
	
	
}
