package com.nttdata.abstractdemo;

public class Employee {

}
