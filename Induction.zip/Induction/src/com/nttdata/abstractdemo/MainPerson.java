package com.nttdata.abstractdemo;

public class MainPerson {

	public static void main(String[] args) {
		
	}

}
