package com.nttdata.abstractdemo;

public class Triangle extends Shape {
	void myTriangle()
	{
		System.out.println("child class triangle");
	}

	@Override
	void area(int height) {
		float res;
		res=(height*23)/2;
		System.out.println("result:"+res);
	}
	
}
