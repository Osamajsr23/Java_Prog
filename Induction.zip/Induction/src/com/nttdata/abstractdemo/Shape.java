package com.nttdata.abstractdemo;

abstract public class Shape {
	
	void triangle()
	{
		System.out.println("Triangle method");
		
	}
	abstract void  area(int num);
}
