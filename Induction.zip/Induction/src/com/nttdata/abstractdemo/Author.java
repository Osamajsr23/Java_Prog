package com.nttdata.abstractdemo;

public class Author {
	
}
