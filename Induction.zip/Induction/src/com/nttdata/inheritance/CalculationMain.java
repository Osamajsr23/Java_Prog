package com.nttdata.inheritance;

public class CalculationMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Addition a = new Addition();
		System.out.println("num1:"+a.num1);
		System.out.println("num2:"+a.num2);
		a.add();
	}

}
