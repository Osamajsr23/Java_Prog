package com.nttdata.inheritance;

public class A {
	
	int a;
	int b;
	int c;
	
}
