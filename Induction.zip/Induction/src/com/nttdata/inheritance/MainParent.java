package com.nttdata.inheritance;

public class MainParent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child c = new Child();
		c.dispName();
	}

}
