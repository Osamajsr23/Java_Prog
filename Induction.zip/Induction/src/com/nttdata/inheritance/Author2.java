package com.nttdata.inheritance;

public class Author2 extends Person2 {
	
	String book;
	int isbn;
	
	void authorDetails()
	{
		System.out.println("Enter your name, person id, book name, and book id :");
		name = sc.next();
		pid=sc.nextInt();
		book=sc.next();
		isbn=sc.nextInt();
		
		System.out.println("Author name: "+name);
		System.out.println("Author id: "+pid);
		System.out.println("Book name: "+book);
		System.out.println("Book id: "+isbn);
		
		
	}
}
