package com.nttdata.inheritance;
import java.util.Scanner;

public class Person2 {
	String name;
	int pid;
	Scanner sc= new Scanner(System.in);
}
