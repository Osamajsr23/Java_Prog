package com.nttdata.inheritance;
import com.nttdata.interfacedemo.Demo;
public class Calculation {
	int num1=10;
	int num2=20;
	
}
