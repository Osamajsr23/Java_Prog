package com.nttdata.inheritance;

public class Child extends Parent{
	String name = "Derived class";
	
	void dispName()
	{
		System.out.println("parent :"+super.name);
		System.out.println("Child :"+name);
	}
}
