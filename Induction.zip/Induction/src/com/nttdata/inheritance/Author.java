package com.nttdata.inheritance;

public class Author extends Person {
	String name;
	Author()
	{
		super("Parent Class");
		name="Author Class";
	}
	void dispName()
	{
		System.out.println("Parent : "+super.name);
		System.out.println("Child : "+name);
	}

}
