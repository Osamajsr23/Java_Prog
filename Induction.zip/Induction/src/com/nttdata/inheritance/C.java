package com.nttdata.inheritance;

public class C extends B{
	B cal = new B();
	int res;
	 void operation() {
		 res=(a*b)/c;
		 System.out.println("value of a:"+cal.a);
		 System.out.println("Value of b:"+cal.b);
		 System.out.println("Result:"+res);
			
	 }
	
	
	
	
}
