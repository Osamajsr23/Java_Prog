package com.nttdata.inheritance;

public class Addition extends Calculation {
	int res;
	void add()
	{
		//res=cal.num1+cal.num2;
		res=num1+num2;
		System.out.println("Result:"+res);
	}
}
