package com.nttdata.inheritance;

public class MainParent1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child1 c = new Child1();
		c.dispName();
	}

}
