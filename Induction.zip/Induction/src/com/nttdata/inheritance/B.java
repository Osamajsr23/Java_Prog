package com.nttdata.inheritance;

public class B extends A {
	 int a=10;
	 int b=20;
	 int c=2;
}
