package com.nttdata.inheritance;

public class Employee2 extends Person2 {

	String project;
	int eid;
	
	void employeeDetails()
	{
		System.out.println("Enter your name, pid, project,  and eid :");
		name = sc.next();
		pid=sc.nextInt();
		project=sc.next();
		eid=sc.nextInt();
		
		System.out.println("person name: "+name);
		System.out.println("person id: "+pid);
		System.out.println("project name: "+project);
		System.out.println("employee id: "+eid);
		
		
	}
}
