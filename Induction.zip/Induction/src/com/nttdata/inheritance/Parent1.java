package com.nttdata.inheritance;

public class Parent1 {
	String name = " Base Class";
	void dispName()
	{
		System.out.println("Parent:"+name);
	}
}
