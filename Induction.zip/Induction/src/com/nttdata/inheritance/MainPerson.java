package com.nttdata.inheritance;

public class MainPerson {

	public static void main(String[] args) {
		Author a = new Author();
		a.dispName();
	}

}
