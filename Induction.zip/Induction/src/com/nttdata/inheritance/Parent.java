package com.nttdata.inheritance;

public class Parent {
	String name = "Base class";
}
