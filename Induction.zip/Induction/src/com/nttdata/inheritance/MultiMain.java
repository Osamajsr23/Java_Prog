package com.nttdata.inheritance;

public class MultiMain {

	public static void main(String[] args) {
		C calculation = new C();
		calculation.operation();
	}

}
