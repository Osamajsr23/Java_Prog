package com.nttdata.inheritance;

public class Child1 extends Parent1{
	String name = "Derived class";
	void dispName()
	{
		super.dispName();//method overriding
		System.out.println("Child: "+name);
	}
}
