package com.nttdata.inheritance;

public class MainPerson2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Author2 a = new Author2();
		Employee2 e = new Employee2();
		a.authorDetails();
		e.employeeDetails();
	}

}
