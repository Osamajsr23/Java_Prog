package com.nttdta.basic;

public class Marks {

	float marks[][]= {{1.0f,1.1f,1.2f,1.3f,1.4f},{2.0f,2.1f,2.2f,2.3f,2.4f,2.5f}};
	
}
