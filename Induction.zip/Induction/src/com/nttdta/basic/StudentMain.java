package com.nttdta.basic;

public class StudentMain {

	public static void main(String[] args) {
		StudentDetails s = new StudentDetails();
		s.inputDetails();
		s.displayDetails();
	}

}
