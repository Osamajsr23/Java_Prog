package com.nttdta.basic;

import java.util.Scanner;
public class StudentDetails {
	
	Scanner sc = new Scanner(System.in);
	Student student=new Student();
	
	void inputDetails() {
		System.out.println("enter your name");
		student.setName(sc.nextLine());
		System.out.println("enter your id");
		student.setId(sc.nextInt());
		System.out.println("enter your marks");
		student.setMarks(sc.nextFloat());
	}
	
	void displayDetails() {
		System.out.println("Name:"+student.getName());
		System.out.println("Id:"+student.getId());
		System.out.println("Marks:"+student.getMarks());
	}
}
